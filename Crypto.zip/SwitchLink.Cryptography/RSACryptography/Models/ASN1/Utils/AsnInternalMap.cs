﻿using System;

namespace SwitchLink.Cryptography.RSACryptography.Models.Asn1.Utils {
	class AsnInternalMap {
		public Int64 LevelStart { get; set; }
		public Int64 LevelEnd { get; set; }
	}
}
